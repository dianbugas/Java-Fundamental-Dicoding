package com.uangzidni;

public class TotalUang {
    public  static void main(String []args){
        Penghasilan jumlah = new Penghasilan();
        jumlah.info();
    }
}
