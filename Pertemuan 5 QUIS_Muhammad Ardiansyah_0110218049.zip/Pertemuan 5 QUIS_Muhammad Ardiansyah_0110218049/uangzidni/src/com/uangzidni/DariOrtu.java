package com.uangzidni;

public class DariOrtu {
    protected int uang;

    public DariOrtu(){
        uang = 1680000;
    }

    public void info(){
        System.out.println("Uang : + uang");
    }
}
