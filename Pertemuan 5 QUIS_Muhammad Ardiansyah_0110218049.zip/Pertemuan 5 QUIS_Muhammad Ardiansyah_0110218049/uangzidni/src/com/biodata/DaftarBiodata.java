package com.biodata;
import java.sql.SQLOutput;
import java.util.*;
public class DaftarBiodata {
    public static void main(String []args){
        Scanner in = new Scanner(System.in);
        System.out.println("==========DAFTAR BIODATA======");
        Biodata Mahasiswa = new Biodata("Nanada", "0110218049", "Jakarta", "TI", 90);
        System.out.println("==============================");
    }
}
